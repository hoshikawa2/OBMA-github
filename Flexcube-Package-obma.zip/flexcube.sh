su - gsh
cd /
wget "https://objectstorage.us-ashburn-1.oraclecloud.com/p/lmQLGI9bmWMWT2ZrxtumPPUn7xiKxY_5-vtaQi8WwNmhO77K7wZ7x5g4ZezxZvAy/n/id3kyspkytmr/b/bucket_banco_conceito/o/obma144_19Jan21obma144.zip"
unzip -o obma144_19Jan21obma144.zip -d /
cd /scratch/gsh/obma144/user_projects/domains/obma/bin

